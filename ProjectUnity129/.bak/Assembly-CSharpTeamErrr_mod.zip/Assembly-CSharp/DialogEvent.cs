public class DialogEvent : MainDialog
{
}
