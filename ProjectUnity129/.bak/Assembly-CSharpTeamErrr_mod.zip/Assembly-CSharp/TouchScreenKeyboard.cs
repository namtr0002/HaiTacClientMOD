using UnityEngine;

public class TouchScreenKeyboard
{
	public static bool hideInput;

	public static bool visible;

	public bool done;

	public bool active;

	public string text;

	private UnityEngine.TouchScreenKeyboard unityKeyboard;

	public static TouchScreenKeyboard Open(string text, TouchScreenKeyboardType t, bool b1, bool b2, bool type, bool b3, string caption)
{
    if (Application.platform == RuntimePlatform.IPhonePlayer || Application.platform == RuntimePlatform.Android)
    {
        // Removed hideInput = true; to respect external setting
        UnityEngine.TouchScreenKeyboardType unityType = (UnityEngine.TouchScreenKeyboardType)(int)t;
        UnityEngine.TouchScreenKeyboard unityKb = UnityEngine.TouchScreenKeyboard.Open(text, unityType, b1, b2, type, b3, caption);
        
        if (unityKb != null)
        {
            TouchScreenKeyboard wrapper = new TouchScreenKeyboard();
            wrapper.unityKeyboard = unityKb;
            wrapper.text = text;
            wrapper.active = true;
            wrapper.done = false;
            visible = true;
            return wrapper;
        }
    }
    visible = false;
    return null;
}

	public static void Clear()
	{
		visible = false;
	}

	// Cập nhật trạng thái từ Unity keyboard - nên gọi trong TField.update()
	public void Update()
	{
		if (unityKeyboard != null)
		{
			// Cập nhật text từ Unity keyboard
			text = unityKeyboard.text;
			
			// Cập nhật trạng thái active
			active = unityKeyboard.active;
			visible = active;
			
			// Cập nhật trạng thái done
			done = unityKeyboard.status == UnityEngine.TouchScreenKeyboard.Status.Done || 
			       unityKeyboard.status == UnityEngine.TouchScreenKeyboard.Status.Canceled;
		}
	}
}
