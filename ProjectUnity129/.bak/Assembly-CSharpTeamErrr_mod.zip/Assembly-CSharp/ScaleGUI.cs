using System.Collections.Generic;
using UnityEngine;

public class ScaleGUI
{
	public static bool scaleScreen;

	public static float WIDTH;

	public static float HEIGHT;

	private static List<Matrix4x4> stack = new List<Matrix4x4>();

	public static void initScaleGUI()
	{
		// Wait for screen dimensions to be properly initialized
		// This is especially important on Android where Screen.width/height 
		// may not be immediately available
		if (Screen.width <= 0 || Screen.height <= 0)
		{
			// Fallback to a safe default if screen dimensions not yet available
			WIDTH = 720f;
			HEIGHT = 1280f;
			scaleScreen = false;
			Cout.println("Init Scale GUI: Waiting for screen dimensions. Using default: " + WIDTH + "x" + HEIGHT);
			return;
		}
		
		Cout.println("Init Scale GUI: Screen.w=" + Screen.width + " Screen.h=" + Screen.height);
		
		// For mobile devices (Android/iOS), use actual screen dimensions
		// For PC, use fixed reference dimensions
		bool isMobile = Application.platform == RuntimePlatform.Android || Application.platform == RuntimePlatform.IPhonePlayer;
		
		if (isMobile)
		{
			float width = Screen.width;
			float height = Screen.height;
			
			// Some devices report 0 in the first couple of frames, fall back to currentResolution.
			if (width <= 0f || height <= 0f)
			{
				width = Screen.currentResolution.width;
				height = Screen.currentResolution.height;
			}
			
			// Make sure the reported dimensions match the actual orientation.
			// Unity can occasionally return portrait sized values even when the game is in landscape
			// (especially right after forcing the orientation). In that case we swap them so that the
			// long side always reflects the landscape width.
			if ((Screen.orientation == ScreenOrientation.LandscapeLeft || Screen.orientation == ScreenOrientation.LandscapeRight || Screen.width >= Screen.height) && width < height)
			{
				float num = width;
				width = height;
				height = num;
			}
			else if ((Screen.orientation == ScreenOrientation.Portrait || Screen.orientation == ScreenOrientation.PortraitUpsideDown) && height < width)
			{
				float num2 = height;
				height = width;
				width = num2;
			}
			
			WIDTH = width;
			HEIGHT = height;
			scaleScreen = false; // Don't use BeginGUI/EndGUI for mGraphics system
			
			Cout.println("Mobile detected - WIDTH=" + WIDTH + " HEIGHT=" + HEIGHT);
		}
		else
		{
			// For PC, use the set resolution
			WIDTH = Screen.width;
			HEIGHT = Screen.height;
			scaleScreen = false;
			
			Cout.println("PC detected - WIDTH=" + WIDTH + " HEIGHT=" + HEIGHT);
		}
		
		// Ensure minimum valid dimensions
		if (WIDTH <= 0) WIDTH = 720f;
		if (HEIGHT <= 0) HEIGHT = 1280f;
		
		Cout.println("Final Scale GUI: WIDTH=" + WIDTH + " HEIGHT=" + HEIGHT);
	}

	public static void BeginGUI()
	{
		if (scaleScreen)
		{
			stack.Add(GUI.matrix);
			Matrix4x4 matrix4x = default(Matrix4x4);
			float num = Screen.width;
			float num2 = Screen.height;
			float num3 = num / num2;
			float num4 = 1f;
			Vector3 zero = Vector3.zero;
			num4 = ((!(num3 < WIDTH / HEIGHT)) ? ((float)Screen.height / HEIGHT) : ((float)Screen.width / WIDTH));
			matrix4x.SetTRS(zero, Quaternion.identity, Vector3.one * num4);
			GUI.matrix *= matrix4x;
		}
	}

	public static void EndGUI()
	{
		if (scaleScreen)
		{
			GUI.matrix = stack[stack.Count - 1];
			stack.RemoveAt(stack.Count - 1);
		}
	}

	public static float scaleX(float x)
	{
		if (!scaleScreen)
		{
			return x;
		}
		x = x * WIDTH / (float)Screen.width;
		return x;
	}

	public static float scaleY(float y)
	{
		if (!scaleScreen)
		{
			return y;
		}
		y = y * HEIGHT / (float)Screen.height;
		return y;
	}
}
