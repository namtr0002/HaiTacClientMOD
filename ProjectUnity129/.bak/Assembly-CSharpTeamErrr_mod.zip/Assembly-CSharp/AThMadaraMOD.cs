using System;
using System.Collections.Generic;

public class AThMadaraMOD
{
	public Player myChar;
	public const int MENU_AUTO_W = 11;
	public const int MENU_AUTO_H = 14;
	public const int MENU_AUTO_OFFSET_X = 3;
	public const int MENU_AUTO_OFFSET_Y = -20;
	public const int MENU_TOUCH_PAD = 4;
	private static AThMadaraMOD instance;
	public static mVector pendingDrops = new mVector();
	
	// Trong AThMadaraMOD
	public static bool shouldReturnToLastMap = false;
	public static int lastMapId = -1;
	public static int lastX = -1;
	public static int lastY = -1;
	public static long nextReturnTryAt = 0;
	public static bool triedChangeMapOkOnce = false;

	public static AThMadaraMOD getInstance()
	{
		if (instance == null)
		{
			instance = new AThMadaraMOD();
		}
		return instance;
	}

	private bool isPointerInRect(int px, int py, int rx, int ry, int rw, int rh)
	{
		return px >= rx && px <= rx + rw && py >= ry && py <= ry + rh;
	}

	public bool handlePointerReleased(int px, int py)
	{
		if (!GameCanvas.isTouch || GameCanvas.currentScreen != GameCanvas.gameScr)
		{
			return false;
		}
		// Nếu đã có menu đang mở, không xử lý touch nữa
		if (GameCanvas.currentDialog != null || (GameCanvas.menuCur != null && GameCanvas.menuCur.isShowMenu) || Player.isGhost)
		{
			return false;
		}
		
		// QUAN TRỌNG: Kiểm tra KHÔNG phải nút auto fire cũ trước
		// Nếu touch vào nút auto fire cũ, KHÔNG xử lý ở đây
		// Nút auto fire: icon 22x22, vẽ tại (xAutoFire, yAutoFire) với anchor 0,0
		// Với anchor 0,0: (x,y) là góc trên bên trái, icon chiếm từ x đến x+22, y đến y+22
		// Hitbox mở rộng thêm 8px padding mỗi bên để dễ bấm
		int autoFireIconW = 22;
		int autoFireIconH = 22;
		int autoFirePadding = 8; // padding mỗi bên
		int autoFireW = autoFireIconW + autoFirePadding * 2; // 22 + 16 = 38
		int autoFireH = autoFireIconH + autoFirePadding * 2; // 22 + 16 = 38
		int autoFireRx = Interface_Game.xAutoFire - autoFirePadding; // Bắt đầu từ x - padding
		int autoFireRy = Interface_Game.yAutoFire - autoFirePadding; // Bắt đầu từ y - padding
		if (isPointerInRect(px, py, autoFireRx, autoFireRy, autoFireW, autoFireH))
		{
			// Đây là nút auto fire cũ, để Interface_Game xử lý
			return false;
		}
		
		// Chỉ kiểm tra touch vào nút MOD
		// Icon MOD: 11x14, vẽ tại (xModButton, yModButton) với anchor 0,0
		// Với anchor 0,0: (x,y) là góc trên bên trái, icon chiếm từ x đến x+11, y đến y+14
		// Hitbox mở rộng thêm 10px padding mỗi bên để dễ bấm (vì icon nhỏ hơn)
		int modIconW = 11;
		int modIconH = 14;
		int modPadding = 10; // padding mỗi bên
		int modButtonW = modIconW + modPadding * 2; // 11 + 20 = 31
		int modButtonH = modIconH + modPadding * 2; // 14 + 20 = 34
		int modRx = Interface_Game.xModButton - modPadding; // Bắt đầu từ x - padding
		int modRy = Interface_Game.yModButton - modPadding; // Bắt đầu từ y - padding
		if (isPointerInRect(px, py, modRx, modRy, modButtonW, modButtonH))
		{
			// Clear pointer select TRƯỚC khi mở menu để tránh conflict
			GameCanvas.isPointerSelect = false;
			openMenuAuto();
			// Return true để không clear pointer ở GameCanvas.onPointerReleased
			return true;
		}
		
		// Không xử lý vùng backup menu nữa để tránh conflict với nút auto fire
		return false;
	}

	public void openMenuAuto()
	{
		try
		{
			mVector menu = new mVector();
			iCommand cmd1 = new iCommand("Tàn Sát", 108, GameCanvas.gameScr);
			cmd1.isDonotCloseMenu = false; // Cho phép đóng menu khi chọn
			menu.addElement(cmd1);
			
			iCommand cmd2 = new iCommand("Đóng băng quái", 111, GameCanvas.gameScr);
			cmd2.isDonotCloseMenu = false;
			menu.addElement(cmd2);
			
			iCommand cmd3 = new iCommand("Gom quái", 112, GameCanvas.gameScr);
			cmd3.isDonotCloseMenu = false;
			menu.addElement(cmd3);
			
			iCommand cmd4 = new iCommand("Speed", 114, GameCanvas.gameScr);
			cmd4.isDonotCloseMenu = false;
			menu.addElement(cmd4);
			
			iCommand cmd5 = new iCommand("FPS", 120, GameCanvas.gameScr);
			cmd5.isDonotCloseMenu = false;
			menu.addElement(cmd5);
			
			iCommand cmd6 = new iCommand("Tự hồi sinh[" + (Player.isAutoRevice ? "Bật" : "Tắt") + "]", 118, GameCanvas.gameScr);
			cmd6.isDonotCloseMenu = false;
			menu.addElement(cmd6);
			
			GameCanvas.menu.startAt(menu, 2, "Menu Auto");
		}
		catch (Exception)
		{
		}
	}

	public void openMenuSellItem()
	{
		// TODO: Implement MsgAutoSell dialog
		Interface_Game.addInfoPlayerNormal("Auto Sell - Coming soon", mFont.tahoma_7_yellow);
	}

	// Trong class AThMadaraMOD
	public static mVector autoSellList = new mVector("AutoSellList");

	// filter mode: 0 = all, 1 = only white (colorName==0), 2 = white+green (<=1)
	public static int AUTOSELL_FILTER = 0;

	// Kiểm tra xem MainItem đã trong danh sách auto-sell chưa
	public static bool isInAutoSell(MainItem mi)
	{
		if (mi == null)
		{
			return false;
		}
		for (int i = 0; i < autoSellList.size(); i++)
		{
			short[] s = (short[])autoSellList.elementAt(i);
			if (s != null && s[0] == (short)mi.typeObject && s[1] == (short)mi.ID)
			{
				return true;
			}
		}
		return false;
	}

	// Toggle vật phẩm: nếu chưa có => add, có rồi => remove
	public static void toggleAutoSell(MainItem mi)
	{
		if (mi == null)
		{
			return;
		}
		for (int i = 0; i < autoSellList.size(); i++)
		{
			short[] s = (short[])autoSellList.elementAt(i);
			if (s != null && s[0] == (short)mi.typeObject && s[1] == (short)mi.ID)
			{
				autoSellList.removeElementAt(i);
				Interface_Game.addInfoPlayerNormal("Đã bỏ khỏi danh sách auto-sell: " + mi.name, mFont.tahoma_7_yellow);
				return;
			}
		}
		short[] entry = new short[2];
		entry[0] = (short)mi.typeObject;
		entry[1] = (short)mi.ID;
		autoSellList.addElement(entry);
		Interface_Game.addInfoPlayerNormal("Đã thêm vào danh sách auto-sell: " + mi.name, mFont.tahoma_7_yellow);
	}

	// Xóa toàn bộ danh sách
	public static void clearAutoSellList()
	{
		autoSellList.removeAllElements();
		Interface_Game.addInfoPlayerNormal("Xóa toàn bộ danh sách auto-sell", mFont.tahoma_7_yellow);
	}

	// Bỏ 1 item theo index danh sách autoSellList
	public static void removeAutoSellAt(int idx)
	{
		if (idx >= 0 && idx < autoSellList.size())
		{
			short[] s = (short[])autoSellList.elementAt(idx);
			autoSellList.removeElementAt(idx);
			Interface_Game.addInfoPlayerNormal("Đã xóa mục auto-sell", mFont.tahoma_7_yellow);
		}
	}

	// Làm sạch cache: xóa các item không còn trong inventory
	public static void cleanAutoSellCache()
	{
		if (Player.vecInventory == null)
		{
			return;
		}

		mVector toRemove = new mVector();
		for (int i = 0; i < autoSellList.size(); i++)
		{
			short[] s = (short[])autoSellList.elementAt(i);
			if (s == null)
			{
				toRemove.addElement(i);
				continue;
			}

			// Kiểm tra xem item này còn trong inventory không
			bool found = false;
			for (int j = 0; j < Player.vecInventory.size(); j++)
			{
				MainItem mi = (MainItem)Player.vecInventory.elementAt(j);
				if (mi != null && mi.typeObject == s[0] && mi.ID == s[1])
				{
					found = true;
					break;
				}
			}

			if (!found)
			{
				toRemove.addElement(i);
			}
		}

		// Xóa các item không còn trong inventory
		for (int i = toRemove.size() - 1; i >= 0; i--)
		{
			int idx = (int)toRemove.elementAt(i);
			autoSellList.removeElementAt(idx);
		}

		if (toRemove.size() > 0)
		{
			Interface_Game.addInfoPlayerNormal("Đã làm sạch " + toRemove.size() + " item không còn trong túi", mFont.tahoma_7_yellow);
		}
	}

	// Helper kiểm tra pending
	private static bool isPending(MainItem mi)
	{
		if (mi == null)
		{
			return false;
		}
		for (int p = 0; p < pendingDrops.size(); p++)
		{
			short[] s = (short[])pendingDrops.elementAt(p);
			if (s != null && s[0] == (short)mi.typeObject && s[1] == (short)mi.ID)
			{
				return true;
			}
		}
		return false;
	}

	private static void addPending(MainItem mi)
	{
		if (mi == null || isPending(mi))
		{
			return;
		}
		short[] entry = new short[2];
		entry[0] = (short)mi.typeObject;
		entry[1] = (short)mi.ID;
		pendingDrops.addElement(entry);
	}

	private static void removePendingIfNotExistsInInventory()
	{
		if (Player.vecInventory == null)
		{
			return;
		}
		mVector toRemove = new mVector();
		for (int i = 0; i < pendingDrops.size(); i++)
		{
			short[] s = (short[])pendingDrops.elementAt(i);
			bool found = false;
			for (int j = 0; j < Player.vecInventory.size(); j++)
			{
				MainItem mi = (MainItem)Player.vecInventory.elementAt(j);
				if (mi != null && mi.typeObject == s[0] && mi.ID == s[1])
				{
					found = true;
					break;
				}
			}
			if (!found)
			{
				toRemove.addElement(i);
			}
		}
		for (int k = toRemove.size() - 1; k >= 0; k--)
		{
			int idx = (int)toRemove.elementAt(k);
			if (idx >= 0 && idx < pendingDrops.size())
			{
				pendingDrops.removeElementAt(idx);
			}
		}
		if (toRemove.size() > 0)
		{
			Interface_Game.addInfoPlayerNormal("Đã cập nhật trạng thái AutoDrop", mFont.tahoma_7_yellow);
		}
	}

	// Auto process items
	public static void autoProcessItems()
	{
		if (Player.vecInventory == null || GameCanvas.gameTick % 20 != 0)
		{
			return;
		}

		// Chỉ chạy khi bật AutoDrop
		if (!Player.isAutoFilterItems)
		{
			return;
		}

		// Dọn các pending đã mất khỏi inventory
		removePendingIfNotExistsInInventory();

		for (int i = Player.vecInventory.size() - 1; i >= 0; i--)
		{
			MainItem mi = (MainItem)Player.vecInventory.elementAt(i);
			if (mi != null && isInAutoSell(mi))
			{
				if (isPending(mi))
				{
					continue;
				}
				if (mi.numPotion <= 0)
				{
					continue;
				}
				// TODO: Implement item_drop method
				// GlobalService.gI().item_drop((sbyte)i, (short)mi.numPotion);
				addPending(mi);
				Interface_Game.addInfoPlayerNormal("Tự động vứt: " + mi.name, mFont.tahoma_7_yellow);
			}
		}
	}

	// Trong AThMadaraMOD
	public static void returnToLastMap()
	{
		if (lastMapId <= 0)
		{
			Interface_Game.addInfoPlayerNormal("Không có map cũ để quay lại.", mFont.tahoma_7_yellow);
			shouldReturnToLastMap = false;
			return;
		}
		try
		{
		if (GameCanvas.loadmap == null || GameCanvas.loadmap.idMap != lastMapId)
		{
			if (!triedChangeMapOkOnce && GameCanvas.loadmap != null)
			{
				try
				{
					GameCanvas.loadmap.idMap = lastMapId;
					// GlobalService.gI().changeMapOk();
						Interface_Game.addInfoPlayerNormal("Yêu cầu đổi map (OK) về map cũ...", mFont.tahoma_7_yellow);
					}
					catch
					{
					}
					triedChangeMapOkOnce = true;
					nextReturnTryAt = GameCanvas.timeNow + 1000;
					return;
				}
				if (GameCanvas.timeNow >= nextReturnTryAt)
				{
					GlobalService.gI().NextMap((short)lastMapId);
					Interface_Game.addInfoPlayerNormal("Đang chuyển về map cũ...", mFont.tahoma_7_yellow);
					nextReturnTryAt = GameCanvas.timeNow + 1000;
				}
				return;
			}

			// Đã đúng map → khôi phục khu (zone) nếu có
			try
			{
				AThMadaraFunc.restoreSavedZoneIfAny();
			}
			catch
			{
			}

			// Đã tới đúng map → đưa về tọa độ cũ nếu hợp lệ
			if (lastX > 0 && lastY > 0)
			{
				try
				{
					GlobalService.gI().Obj_Move((short)lastX, (short)lastY);
					if (GameScreen.player != null)
					{
						GameScreen.player.x = lastX;
						GameScreen.player.y = lastY;
						Player.isSendMove = true;
					}
				}
				catch
				{
				}
			}

			Interface_Game.addInfoPlayerNormal("Đã quay lại vị trí cũ.", mFont.tahoma_7_yellow);

			// Hoàn tất thành công, xóa cờ
			shouldReturnToLastMap = false;
			lastMapId = -1;
			lastX = -1;
			lastY = -1;
			nextReturnTryAt = 0;
			triedChangeMapOkOnce = false;
		}
		catch (Exception)
		{
			Interface_Game.addInfoPlayerNormal("Lỗi khi quay lại map cũ.", mFont.tahoma_7_yellow);
		}
	}
}
