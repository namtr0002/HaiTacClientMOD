using System;
using System.Collections.Generic;

public class AThMadaraFunc
{
	private const int TELEPORT_MAX_TILES = 6;
	private static Dictionary<MainMonster, int[]> gomSavedGlobal = null;
	private static bool gomFollowPlayer = false;
	public static bool gomUseMapCenter = false;
	public static int gomOffsetX = 0;
	public static int gomOffsetY = 0;
	public static int gomFixedX = 0;
	public static int gomFixedY = 0;

	public static void autoFireMoveToTarget(Player p)
	{
		if (p == null)
		{
			return;
		}
		if (p.skillCurrent != null)
		{
			return;
		}
		try
		{
			if (Player.typeAutoBuff == 1 && MsgAutoFire.value != null)
			{
				if (GameCanvas.gameTick % 5 == 1)
				{
					for (int i = 0; i < MsgAutoFire.value.Length; i++)
					{
						short id = MsgAutoFire.value[i][0];
						short enabled = MsgAutoFire.value[i][1];
						if (enabled != 1)
						{
							continue;
						}
						Skill_Info sk = Skill_Info.getSkillFromID(id);
						if (sk == null)
						{
							continue;
						}
						if (p.getManaNeedUse((int)sk.manaLost) > p.Mp)
						{
							continue;
						}
						if (!DelaySkill.getDelay(sk.indexHotKey).isCoolDown())
						{
							continue;
						}
						try
						{
						bool started = p.beginPlayerFire(sk);
						if (started)
						{
							// timeFristSkill is private, skip
							return;
						}
						}
						catch
						{
						}
					}
				}
			}
		}
		catch
		{
		}

		if (gomSavedGlobal != null && gomUseMapCenter)
		{
			try
			{
				p.x = gomFixedX;
				p.y = gomFixedY;
				p.toX = gomFixedX;
				p.toY = gomFixedY;
				p.toXNew = gomFixedX;
				p.toYNew = gomFixedY;
				p.vx = 0;
				p.vy = 0;
				p.posTransRoad = null;
			}
			catch
			{
			}
		}

		if (!p.isAutoFireNew108)
		{
			return;
		}

		MainObject tgt = GameScreen.objFocus;
		// Chỉ cho phép: quái/boss. Nếu focus hiện tại không hợp lệ, bỏ focus và tìm lại.
		if (tgt == null || !isAllowedTargetForAuto(p, tgt))
		{
			GameScreen.objFocus = null;
			// Tìm mục tiêu hợp lệ gần nhất
			int best = int.MaxValue;
			MainObject bestObj = null;
			for (int i = 0; i < GameScreen.vecPlayers.size(); i++)
			{
				MainObject o = (MainObject)GameScreen.vecPlayers.elementAt(i);
				if (o == null)
				{
					continue;
				}
				if (!isAllowedTargetForAuto(p, o))
				{
					continue;
				}
				if (o.isRemove || o.isDie || o.Hp <= 0)
				{
					continue;
				}
				int d = MainObject.getDistance(p.x, p.y, o.x, o.y);
				if (d < best)
				{
					best = d;
					bestObj = o;
				}
			}
			if (bestObj != null)
			{
				GameScreen.objFocus = bestObj;
				tgt = bestObj;
			}
			else
			{
				return;
			}
		}

		if (tgt.isRemove || tgt.Hp <= 0 || tgt.isDie)
		{
			try
			{
				p.nextMonster();
			}
			catch
			{
			}
			tgt = GameScreen.objFocus;
			if (tgt == null || !isAllowedTargetForAuto(p, tgt))
			{
				return;
			}
		}
		// Nếu gom theo center thì bỏ qua kiểm tra attackable; còn lại phải hợp lệ
		if (!isAllowedTargetForAuto(p, tgt) && (gomSavedGlobal == null || !gomUseMapCenter))
		{
			return;
		}

		Hotkey[] row = Player.hotkeyPlayer != null ? Player.hotkeyPlayer[Player.currentTab] : null;
		if (row == null || row.Length == 0)
		{
			return;
		}
		int n = row.Length;
		bool isAutoNew = p.isAutoFireNew108;
		if (isAutoNew)
		{
			if (Player.IndexFire < 0 || Player.IndexFire >= n)
			{
				Player.IndexFire = 0;
			}
		}

		int tileSize = GameCanvas.loadmap != null && LoadMap.wTile > 0
			? LoadMap.wTile
			: (LoadMap.wTile > 0 ? LoadMap.wTile : 24);
		double teleportMaxPixels = TELEPORT_MAX_TILES * tileSize;

		for (int iter = 0; iter < n; iter++)
		{
			int slot = isAutoNew ? ((Player.IndexFire + iter) % n) : iter;
			Hotkey hk = row[slot];
			if (hk == null)
			{
				continue;
			}
			if (hk.itemcur != null)
			{
				try
				{
					p.setActionHotKey(slot);
					if (isAutoNew)
					{
						Player.IndexFire = (slot + 1) % n;
					}
				}
				catch
				{
				}
				break;
			}
			if (hk.skill != null)
			{
				Skill_Info sk = Skill_Info.getSkillFromID(hk.skill.ID);
				if (sk == null)
				{
					continue;
				}
				if (!DelaySkill.getDelay(sk.indexHotKey).isCoolDown())
				{
					continue;
				}
				if (p.getManaNeedUse((int)sk.manaLost) > p.Mp)
				{
					continue;
				}
				if (sk.typeSkill == 2)
				{
					try
					{
						p.setActionHotKey(slot);
						if (isAutoNew)
						{
							Player.IndexFire = (slot + 1) % n;
						}
					}
					catch
					{
					}
					break;
				}
				if (gomSavedGlobal != null && gomUseMapCenter)
				{
					try
					{
						p.setActionHotKey(slot);
						if (isAutoNew)
						{
							Player.IndexFire = (slot + 1) % n;
						}
					}
					catch
					{
					}
					break;
				}
				double dx = p.x - tgt.x;
				double dy = p.y - tgt.y;
				double dist = System.Math.Sqrt(dx * dx + dy * dy);
				// Sửa: teleport khi quá xa (dist > max), không phải khi quá gần
				bool doTeleport = dist > teleportMaxPixels;

				if (doTeleport)
				{
					int tx = (tgt.x / tileSize) * tileSize + tileSize / 2;
					int ty = (tgt.y / tileSize) * tileSize + tileSize / 2;
					sendTeleport(p, tx, ty);
					p.posTransRoad = null;
					try
					{
						p.vx = 0;
						p.vy = 0;
					}
					catch
					{
					}
				}

				try
				{
					p.setActionHotKey(slot);
					if (isAutoNew)
					{
						Player.IndexFire = (slot + 1) % n;
					}
				}
				catch
				{
				}
				break;
			}
		}
	}

	// Chỉ đánh: quái/boss (typeObject==1). Bỏ qua NPC và người chơi.
	private static bool isAllowedTargetForAuto(Player p, MainObject t)
	{
		if (t == null)
		{
			return false;
		}
		return t.typeObject == 1;
	}

	public static Dictionary<MainMonster, int[]> startGomAllFollow(Player p, int offsetX, int offsetY, bool follow, bool useMapCenter)
	{
		Dictionary<MainMonster, int[]> saved = new Dictionary<MainMonster, int[]>();
		if (p == null)
		{
			return saved;
		}

		try
		{
			mVector vec = GameScreen.vecPlayers;
			if (vec == null)
			{
				return saved;
			}

			int targetX;
			int targetY;
			if (useMapCenter && GameCanvas.loadmap != null)
			{
				int maxW = GameCanvas.loadmap.maxWMap;
				int maxH = (int)(GameCanvas.loadmap.maxHMap >= 0 ? GameCanvas.loadmap.maxHMap : (GameCanvas.h > 0 ? GameCanvas.h : maxW));
				targetX = maxW / 2 + offsetX;
				targetY = maxH / 2 + offsetY;
				gomFixedX = targetX;
				gomFixedY = targetY;
				gomUseMapCenter = true;
			}
			else
			{
				targetX = p.x + offsetX;
				targetY = p.y + offsetY;
				gomUseMapCenter = false;
			}

			for (int i = 0; i < vec.size(); i++)
			{
				object o = vec.elementAt(i);
				if (o is MainMonster)
				{
					MainMonster m = (MainMonster)o;
					if (m == null || m.isRemove)
					{
						continue;
					}
					try
					{
						saved[m] = new int[] { m.x, m.y, m.toX, m.toY, m.toXNew, m.toYNew, m.vx, m.vy };
					}
					catch
					{
					}
					m.gomX = targetX;
					m.gomY = targetY;
					m.x = targetX;
					m.y = targetY;
					m.toX = targetX;
					m.toY = targetY;
					m.toXNew = targetX;
					m.toYNew = targetY;
					m.vx = 0;
					m.vy = 0;
					m.isGom = true;
				}
			}

			gomSavedGlobal = saved;
			gomFollowPlayer = follow;
			gomOffsetX = offsetX;
			gomOffsetY = offsetY;
		}
		catch
		{
		}
		return saved;
	}

	public static void updateGomPositions(Player p)
	{
		if (p == null)
		{
			return;
		}
		// FIX: Khởi tạo gomSavedGlobal nếu chưa có (trường hợp bật gom lần đầu)
		if (gomSavedGlobal == null)
		{
			gomSavedGlobal = new Dictionary<MainMonster, int[]>();
		}
		try
		{
			int targetX;
			int targetY;
			if (gomUseMapCenter)
			{
				targetX = gomFixedX;
				targetY = gomFixedY;
			}
			else if (gomFollowPlayer)
			{
				targetX = p.x + gomOffsetX;
				targetY = p.y + gomOffsetY;
			}
			else
			{
				IEnumerator<KeyValuePair<MainMonster, int[]>> it = gomSavedGlobal.GetEnumerator();
				if (!it.MoveNext())
				{
					// Nếu không có quái nào trong gomSavedGlobal, sử dụng map center hoặc player position
					if (gomUseMapCenter && GameCanvas.loadmap != null)
					{
						int maxW = GameCanvas.loadmap.maxWMap;
						int maxH = (int)(GameCanvas.loadmap.maxHMap >= 0 ? GameCanvas.loadmap.maxHMap : (GameCanvas.h > 0 ? GameCanvas.h : maxW));
						targetX = maxW / 2;
						targetY = maxH / 2;
					}
					else
					{
						targetX = p.x;
						targetY = p.y;
					}
				}
				else
				{
					MainMonster first = it.Current.Key;
					if (first == null)
					{
						targetX = p.x;
						targetY = p.y;
					}
					else
					{
						targetX = first.gomX;
						targetY = first.gomY;
					}
				}
			}

			// FIX: Check tất cả quái trong vecPlayers và add các quái mới hồi sinh vào gomSavedGlobal
			mVector vec = GameScreen.vecPlayers;
			if (vec != null)
			{
				for (int i = 0; i < vec.size(); i++)
				{
					object o = vec.elementAt(i);
					if (o is MainMonster)
					{
						MainMonster m = (MainMonster)o;
						if (m == null || m.isRemove)
						{
							continue;
						}
						// FIX: Nếu quái mới hồi sinh (không có trong gomSavedGlobal) thì thêm vào
						if (!gomSavedGlobal.ContainsKey(m))
						{
							// Lưu vị trí ban đầu (có thể là vị trí hồi sinh)
							try
							{
								gomSavedGlobal[m] = new int[] { m.x, m.y, m.toX, m.toY, m.toXNew, m.toYNew, m.vx, m.vy };
							}
							catch
							{
							}
						}
						// Update vị trí gom cho tất cả quái (bao gồm cả quái mới hồi sinh)
						m.gomX = targetX;
						m.gomY = targetY;
						m.x = targetX;
						m.y = targetY;
						m.toX = targetX;
						m.toY = targetY;
						m.toXNew = targetX;
						m.toYNew = targetY;
						m.vx = 0;
						m.vy = 0;
						m.isGom = true;
					}
				}
			}

			// FIX: Update các quái cũ trong gomSavedGlobal (backup, phòng trường hợp quái chưa được scan ở trên)
			foreach (MainMonster m in gomSavedGlobal.Keys)
			{
				if (m == null || m.isRemove)
				{
					continue;
				}
				m.gomX = targetX;
				m.gomY = targetY;
				m.x = targetX;
				m.y = targetY;
				m.toX = targetX;
				m.toY = targetY;
				m.toXNew = targetX;
				m.toYNew = targetY;
				m.vx = 0;
				m.vy = 0;
				m.isGom = true;
			}
		}
		catch
		{
		}
	}

	public static void stopGomAll(Dictionary<MainMonster, int[]> saved)
	{
		Dictionary<MainMonster, int[]> toRestore = saved != null ? saved : gomSavedGlobal;
		if (toRestore == null)
		{
			return;
		}
		try
		{
			foreach (KeyValuePair<MainMonster, int[]> e in toRestore)
			{
				MainMonster m = e.Key;
				int[] s = e.Value;
				if (m == null || s == null || s.Length < 8)
				{
					continue;
				}
				try
				{
					m.x = s[0];
					m.y = s[1];
					m.toX = s[2];
					m.toY = s[3];
					m.toXNew = s[4];
					m.toYNew = s[5];
					m.vx = s[6];
					m.vy = s[7];
				}
				catch
				{
				}
				m.isGom = false;
				m.gomX = 0;
				m.gomY = 0;
			}
		}
		catch
		{
		}
		finally
		{
			if (gomSavedGlobal != null)
			{
				gomSavedGlobal.Clear();
			}
			gomSavedGlobal = null;
			gomFollowPlayer = false;
			gomUseMapCenter = false;
			gomOffsetX = gomOffsetY = 0;
			gomFixedX = gomFixedY = 0;
		}
	}

	private static void sendTeleport(Player p, int x, int y)
	{
		try
		{
			GlobalService.gI().Obj_Move((short)x, (short)y);
			p.x = x;
			p.y = y;
			Player.isSendMove = true;
		}
		catch (Exception)
		{
		}
	}

	public static void autoReviceV1(Player p)
	{
		if (p == null || !p.isDie || !Player.isAutoRevice)
		{
			return;
		}
		try
		{
			if (GameCanvas.loadmap != null)
			{
				AThMadaraMOD.lastMapId = GameCanvas.loadmap.idMap;
			}
			if (GameScreen.player != null)
			{
				AThMadaraMOD.lastX = GameScreen.player.x;
				AThMadaraMOD.lastY = GameScreen.player.y;
			}
			try
			{
				saveCurrentZone();
			}
			catch
			{
			}
			AThMadaraMOD.shouldReturnToLastMap = true;
			AThMadaraMOD.triedChangeMapOkOnce = false;
			AThMadaraMOD.nextReturnTryAt = 0;

			// Gửi hồi sinh về làng
			GlobalService.gI().Player_Revice((sbyte)0);
			Interface_Game.addInfoPlayerNormal("Đã hồi sinh. Sẽ quay lại map cũ...", mFont.tahoma_7_yellow);
		}
		catch (Exception)
		{
		}
	}

	private static sbyte savedZone = -1;

	public static void saveCurrentZone()
	{
		// Không tìm thấy biến zone trong client, nhưng có message 23 dùng để đổi khu.
		// Ta không thể đọc khu hiện tại từ client => dựa vào server-side if any.
		// Mặc định giữ -1 nếu không xác định được.
		// Nếu bạn có biến current zone, gán nó vào savedZone ở đây.
	}

	public static void restoreSavedZoneIfAny()
	{
		if (savedZone >= 0 && savedZone <= 9)
		{
			try
			{
				// TODO: Implement zone change method
				// GlobalService.gI().AB((sbyte)0, savedZone);
			}
			catch
			{
			}
		}
	}

	// Kiểm tra xem player đã hồi sinh hoàn toàn chưa
	public static bool isPlayerFullyRevived(Player p)
	{
		if (p == null)
		{
			return false;
		}
		return p.Hp > 0 && !p.isDie && GameCanvas.loadmap != null;
	}
}
